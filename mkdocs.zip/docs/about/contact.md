---
author:
  name: Markus Kohlmeyer
  url: https://github.com/JoeUser78
  email: joeuser@rootservice.org
publisher:
  name: RootService Team
  url: https://github.com/RootService
license:
  name: Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)
  shortname: CC BY-NC-SA 4.0
  url: https://creativecommons.org/licenses/by-nc-sa/4.0/
contributers: []
date: '2002-02-02'
lastmod: '2022-04-28'
title: Kontakt
description: Kontaktmöglichkeiten
keywords:
  - Kontakt
  - mkdocs
  - docs
lang: de
robots: noindex, nofollow
hide:
  - docinfo
search:
  exclude: true
---
# Kontakt
