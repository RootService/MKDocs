# Security Policy
Report vulnerabilities to security@rootservice.org. We aim to acknowledge within 72 hours.
