service apache24 onestop >/dev/null 2>&1
