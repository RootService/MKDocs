service apache24 onestart >/dev/null 2>&1
service nginx onerestart >/dev/null 2>&1
service dovecot onereload >/dev/null 2>&1
service postfix onereload >/dev/null 2>&1
